let balance=1000;
function show(id){document.querySelectorAll('.page').forEach(x=>x.classList.add('hidden'));document.getElementById(id).classList.remove('hidden');document.getElementById('title').textContent=id==='admin'?'CEO Dashboard':id==='user'?'User Dashboard':'Platform Activity'}
function update(){document.getElementById('balance').textContent='$'+balance.toFixed(2)}
function row(type,amount,status='Complete'){let t=document.getElementById('tx');let r=t.insertRow(1);r.innerHTML=`<td>${type}</td><td>$${amount.toFixed(2)}</td><td><i class="ok">${status}</i></td>`}
function deposit(){balance+=100;update();row('Demo deposit',100);document.getElementById('tradeMsg').textContent='Added $100 demo funds.'}
function withdraw(){if(balance<50){alert('Insufficient demo balance');return}balance-=50;update();row('Demo withdrawal',50);document.getElementById('tradeMsg').textContent='Recorded $50 demo withdrawal.'}
function trade(direction){let a=Number(document.getElementById('amount').value);if(!a||a<1||a>balance){alert('Enter a valid demo amount');return}balance-=a;let win=Math.random()>0.5;let result=win?a*1.8:0;balance+=result;update();row('Demo '+direction,a);document.getElementById('tradeMsg').textContent=win?'Demo result: WIN (+$'+(result-a).toFixed(2)+')':'Demo result: LOSS (-$'+a.toFixed(2)+')'}
