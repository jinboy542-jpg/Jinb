# RonoTrade Demo — Registration & Login

Adds demo user registration and login using browser localStorage.

IMPORTANT: Prototype only. Passwords are stored locally in the browser and are NOT secure. Do not use this for real customer accounts, KYC, deposits, withdrawals, or real-money trading.
